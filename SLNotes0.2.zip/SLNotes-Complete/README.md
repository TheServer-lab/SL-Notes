# SL Notes

A secure, feature-rich Android notes application with end-to-end encryption.

## Features

### 🔐 Security
- **AES-256 Encryption**: All note content is encrypted using AES-256-CBC
- **PBKDF2 Key Derivation**: Master password is securely derived using PBKDF2 with 65,536 iterations
- **Unique IV per Note**: Each note has its own initialization vector for maximum security
- **Searchable Without Decryption**: FTS (Full-Text Search) index allows searching without decrypting all notes

### 📝 Core Features
- Create, edit, and delete notes
- Rich text editor with full-screen editing
- Pin important notes to the top
- Swipe-to-delete with undo functionality

### 🏷️ Organization
- Tags/folders support for categorization
- Multi-tag filtering
- Instant search bar with live filtering
- Multiple sorting options:
  - By title
  - By creation date
  - By last edited date
  - By pinned status

### 🔍 Powerful Search
- Room FTS (Full-Text Search) implementation
- Searches across:
  - Note titles
  - Content previews
  - Tags
- Live results while typing
- Optimized for thousands of notes

### 💾 Backup & Export
- Export individual notes to .txt files
- Encrypted backup system using custom .sln extension
- Import encrypted backups safely
- Restore notes with password protection

### 🎨 Modern UI
- Material 3 Design
- Jetpack Compose UI
- Dark/Light theme support
- Dynamic color support (Android 12+)

## Tech Stack

- **Language**: Kotlin
- **UI Framework**: Jetpack Compose
- **Architecture**: MVVM (Model-View-ViewModel)
- **Database**: Room with FTS4 (Full-Text Search)
- **Async**: Kotlin Coroutines & Flow
- **Compiler**: KSP (Kotlin Symbol Processing)
- **Encryption**: Android Security Crypto & Java Crypto APIs
- **Navigation**: Jetpack Navigation Compose

## Architecture

```
app/
├── data/
│   ├── model/           # Data models (Note, NoteFts)
│   ├── dao/             # Room DAOs
│   ├── database/        # Room Database
│   └── repository/      # Repository pattern
├── ui/
│   ├── screens/         # Compose UI screens
│   ├── viewmodel/       # ViewModels
│   ├── theme/           # Material 3 theme
│   └── navigation/      # Navigation setup
└── util/                # Utilities (Encryption, Backup)
```

## Security Implementation

### Encryption Flow
1. User sets master password
2. Password is derived using PBKDF2 with SHA-256 (65,536 iterations)
3. For each note:
   - Generate unique random IV (16 bytes)
   - Encrypt title and content with AES-256-CBC
   - Store encrypted data + IV in database
4. Search index stores plaintext titles and content previews
5. Full content only decrypted when note is opened

### Key Features
- Notes are encrypted at rest
- Master password never stored in plain text
- Each note has unique IV for security
- Search functionality without exposing encrypted content

## Setup Instructions

### Prerequisites
- Android Studio Hedgehog or later
- JDK 17 or later
- Android SDK 26 or higher
- Gradle 8.2 or later

### Build Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/TheServer-lab/SL-Notes.git
   cd SL-Notes
   ```

2. **Open in Android Studio**
   - Open Android Studio
   - Select "Open an Existing Project"
   - Navigate to the cloned directory
   - Wait for Gradle sync to complete

3. **Build the project**
   ```bash
   ./gradlew build
   ```

4. **Run on device/emulator**
   - Connect Android device or start emulator
   - Click Run (or press Shift+F10)

### First Run
1. App will prompt for master password setup
2. Enter a strong password (minimum 6 characters)
3. Confirm password
4. Start creating encrypted notes!

## Usage

### Creating a Note
1. Tap the floating action button (+)
2. Enter title and content
3. Add tags if needed
4. Tap Save

### Organizing Notes
- **Pin**: Tap the pin icon to keep note at top
- **Tags**: Tap tag icon to add/remove tags
- **Search**: Use search bar to filter notes
- **Sort**: Tap sort icon to change sorting order

### Backup & Restore
1. Go to Settings
2. Tap "Create Encrypted Backup"
3. Enter master password
4. Backup file (.sln) will be created
5. To restore: "Restore from Backup" → Select .sln file → Enter password

## License

Copyright (c) 2025 Sourasish Das

This project is licensed under the Server-Lab Open-Control License (SOCL) 1.0.

See the [LICENSE](LICENSE) file or Settings → License in the app for full license text.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

By contributing, you grant the copyright owner a perpetual, irrevocable license to use your contributions as outlined in the SOCL 1.0 license.

## Roadmap

### Planned Features
- [ ] Biometric authentication (fingerprint/face unlock)
- [ ] Auto-lock after inactivity
- [ ] Rich text formatting (bold, italic, lists)
- [ ] Image attachments
- [ ] Note sharing
- [ ] Cloud sync (optional)
- [ ] Widgets
- [ ] Reminder/notification system

## Security Notice

⚠️ **Important**: This app uses strong encryption, but please note:
- Master password cannot be recovered if forgotten
- Keep backups of your .sln files
- Use a strong, memorable password
- Consider using a password manager

## Support

- **Issues**: [GitHub Issues](https://github.com/TheServer-lab/SL-Notes/issues)
- **Discussions**: [GitHub Discussions](https://github.com/TheServer-lab/SL-Notes/discussions)

## Acknowledgments

- Built with Jetpack Compose and Material 3
- Encryption powered by Android Security Crypto
- Search powered by Room FTS4

---

**Made with ❤️ by Sourasish Das**
