package com.serverlab.slnotes.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.serverlab.slnotes.data.dao.NoteDao
import com.serverlab.slnotes.data.model.Note
import com.serverlab.slnotes.data.model.NoteFts

@Database(
    entities = [Note::class, NoteFts::class],
    version = 2,
    exportSchema = false
)
abstract class NotesDatabase : RoomDatabase() {
    
    abstract fun noteDao(): NoteDao
    
    companion object {
        @Volatile
        private var INSTANCE: NotesDatabase? = null
        
        fun getDatabase(context: Context): NotesDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NotesDatabase::class.java,
                    "sl_notes_database"
                )
                .fallbackToDestructiveMigration() // For development - removes this for production
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
