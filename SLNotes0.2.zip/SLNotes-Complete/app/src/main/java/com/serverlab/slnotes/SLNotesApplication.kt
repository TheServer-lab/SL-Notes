package com.serverlab.slnotes

import android.app.Application

class SLNotesApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
