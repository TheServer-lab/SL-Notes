package com.serverlab.slnotes.util

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object EncryptionUtil {
    
    private const val ALGORITHM = "AES/CBC/PKCS7Padding"
    private const val KEY_ALGORITHM = "AES"
    private const val KEY_DERIVATION_ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val IV_SIZE = 16
    private const val KEY_SIZE = 256
    private const val ITERATION_COUNT = 65536
    
    // Salt should be stored securely, for simplicity using a fixed one
    // In production, consider storing per-user salt in Keystore
    private const val SALT = "SLNotes2025SecureSalt"
    
    /**
     * Derives an AES key from a password using PBKDF2
     */
    fun deriveKeyFromPassword(password: String): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance(KEY_DERIVATION_ALGORITHM)
        val spec = PBEKeySpec(
            password.toCharArray(),
            SALT.toByteArray(),
            ITERATION_COUNT,
            KEY_SIZE
        )
        val key = factory.generateSecret(spec)
        return SecretKeySpec(key.encoded, KEY_ALGORITHM)
    }
    
    /**
     * Generates a random Initialization Vector
     */
    fun generateIV(): ByteArray {
        val iv = ByteArray(IV_SIZE)
        SecureRandom().nextBytes(iv)
        return iv
    }
    
    /**
     * Encrypts plaintext using AES-CBC with the provided key and IV
     * Returns Base64 encoded ciphertext
     */
    fun encrypt(plaintext: String, key: SecretKeySpec, iv: ByteArray): String {
        val cipher = Cipher.getInstance(ALGORITHM)
        cipher.init(Cipher.ENCRYPT_MODE, key, IvParameterSpec(iv))
        val encrypted = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(encrypted, Base64.DEFAULT)
    }
    
    /**
     * Decrypts ciphertext using AES-CBC with the provided key and IV
     * Returns plaintext string
     */
    fun decrypt(ciphertext: String, key: SecretKeySpec, iv: ByteArray): String {
        val cipher = Cipher.getInstance(ALGORITHM)
        cipher.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(iv))
        val encrypted = Base64.decode(ciphertext, Base64.DEFAULT)
        val decrypted = cipher.doFinal(encrypted)
        return String(decrypted, Charsets.UTF_8)
    }
    
    /**
     * Converts IV to Base64 for storage
     */
    fun ivToString(iv: ByteArray): String {
        return Base64.encodeToString(iv, Base64.DEFAULT)
    }
    
    /**
     * Converts Base64 string back to IV bytes
     */
    fun stringToIV(ivString: String): ByteArray {
        return Base64.decode(ivString, Base64.DEFAULT)
    }
    
    /**
     * Generates a preview of content (first 200 chars) for searchable index
     */
    fun generateContentPreview(content: String, maxLength: Int = 200): String {
        return if (content.length <= maxLength) {
            content
        } else {
            content.substring(0, maxLength)
        }
    }
    
    /**
     * Hash password for verification (not for encryption)
     */
    fun hashPassword(password: String): String {
        val factory = SecretKeyFactory.getInstance(KEY_DERIVATION_ALGORITHM)
        val spec = PBEKeySpec(
            password.toCharArray(),
            SALT.toByteArray(),
            ITERATION_COUNT,
            256
        )
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.DEFAULT)
    }
}
