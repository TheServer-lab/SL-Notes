package com.serverlab.slnotes.data.model

import androidx.room.Entity
import androidx.room.Fts4

@Fts4(contentEntity = Note::class)
@Entity(tableName = "notes_fts")
data class NoteFts(
    val titlePlaintext: String,
    val contentPreview: String,
    val tags: String
)
