package com.serverlab.slnotes.util

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.serverlab.slnotes.data.model.Note
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackupUtil {
    
    private val gson = Gson()
    private val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
    
    data class BackupData(
        val version: Int = 1,
        val timestamp: Long,
        val notes: List<Note>
    )
    
    /**
     * Create an encrypted backup file (.sln format)
     */
    suspend fun createBackup(
        context: Context,
        notes: List<Note>,
        password: String
    ): File = withContext(Dispatchers.IO) {
        val timestamp = Date().time
        val backupData = BackupData(
            timestamp = timestamp,
            notes = notes
        )
        
        // Serialize to JSON
        val json = gson.toJson(backupData)
        
        // Encrypt the entire backup
        val key = EncryptionUtil.deriveKeyFromPassword(password)
        val iv = EncryptionUtil.generateIV()
        val encryptedData = EncryptionUtil.encrypt(json, key, iv)
        
        // Create backup file
        val fileName = "sl_notes_backup_${dateFormat.format(Date())}.sln"
        val backupFile = File(context.getExternalFilesDir(null), fileName)
        
        // Store IV + encrypted data
        val ivString = EncryptionUtil.ivToString(iv)
        backupFile.writeText("$ivString\n$encryptedData")
        
        backupFile
    }
    
    /**
     * Restore from encrypted backup file
     */
    suspend fun restoreBackup(
        context: Context,
        uri: Uri,
        password: String
    ): BackupData = withContext(Dispatchers.IO) {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw Exception("Cannot open backup file")
        
        val lines = inputStream.bufferedReader().use { it.readLines() }
        if (lines.size < 2) throw Exception("Invalid backup file format")
        
        val ivString = lines[0]
        val encryptedData = lines.drop(1).joinToString("\n")
        
        // Decrypt
        val key = EncryptionUtil.deriveKeyFromPassword(password)
        val iv = EncryptionUtil.stringToIV(ivString)
        
        try {
            val json = EncryptionUtil.decrypt(encryptedData, key, iv)
            gson.fromJson(json, BackupData::class.java)
        } catch (e: Exception) {
            throw Exception("Failed to decrypt backup. Wrong password?")
        }
    }
    
    /**
     * Export note to plain text file
     */
    suspend fun exportNoteToText(
        context: Context,
        title: String,
        content: String,
        tags: List<String>
    ): File = withContext(Dispatchers.IO) {
        val fileName = "${title.take(30).replace("[^a-zA-Z0-9]".toRegex(), "_")}_${dateFormat.format(Date())}.txt"
        val file = File(context.getExternalFilesDir(null), fileName)
        
        val textContent = buildString {
            appendLine("Title: $title")
            appendLine("Tags: ${tags.joinToString(", ")}")
            appendLine("Exported: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            appendLine()
            appendLine("---")
            appendLine()
            appendLine(content)
        }
        
        file.writeText(textContent)
        file
    }
}
