package com.serverlab.slnotes.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.serverlab.slnotes.data.model.Note
import com.serverlab.slnotes.data.repository.DecryptedNote
import com.serverlab.slnotes.data.repository.NoteRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NotesViewModel(
    private val repository: NoteRepository
) : ViewModel() {
    
    // Master password for encryption
    private val _masterPassword = MutableStateFlow("")
    val masterPassword: StateFlow<String> = _masterPassword.asStateFlow()
    
    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    // Selected tags for filtering
    private val _selectedTags = MutableStateFlow<Set<String>>(emptySet())
    val selectedTags: StateFlow<Set<String>> = _selectedTags.asStateFlow()
    
    // Sort option
    private val _sortBy = MutableStateFlow(NoteRepository.SortBy.UPDATED)
    val sortBy: StateFlow<NoteRepository.SortBy> = _sortBy.asStateFlow()
    
    // All notes
    private val _notes = _sortBy.flatMapLatest { sortOption ->
        repository.getAllNotes(sortOption)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    // Filtered and searched notes
    val displayedNotes: StateFlow<List<Note>> = combine(
        _notes,
        _searchQuery,
        _selectedTags
    ) { notes, query, tags ->
        var filtered = notes
        
        // Filter by tags
        if (tags.isNotEmpty()) {
            filtered = filtered.filter { note ->
                tags.any { tag -> note.tags.contains("\"$tag\"") }
            }
        }
        
        // Search
        if (query.isNotEmpty()) {
            filtered = filtered.filter { note ->
                note.titlePlaintext.contains(query, ignoreCase = true) ||
                note.contentPreview.contains(query, ignoreCase = true) ||
                note.tags.contains(query, ignoreCase = true)
            }
        }
        
        filtered
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    // All available tags
    val allTags: StateFlow<List<String>> = repository.getAllTags()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    // Recently deleted note for undo
    private val _recentlyDeletedNote = MutableStateFlow<Note?>(null)
    val recentlyDeletedNote: StateFlow<Note?> = _recentlyDeletedNote.asStateFlow()
    
    /**
     * Set master password
     */
    fun setMasterPassword(password: String) {
        _masterPassword.value = password
    }
    
    /**
     * Update search query
     */
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }
    
    /**
     * Toggle tag filter
     */
    fun toggleTagFilter(tag: String) {
        _selectedTags.value = if (_selectedTags.value.contains(tag)) {
            _selectedTags.value - tag
        } else {
            _selectedTags.value + tag
        }
    }
    
    /**
     * Clear tag filters
     */
    fun clearTagFilters() {
        _selectedTags.value = emptySet()
    }
    
    /**
     * Change sort option
     */
    fun setSortBy(sortBy: NoteRepository.SortBy) {
        _sortBy.value = sortBy
    }
    
    /**
     * Get note by ID and decrypt
     */
    suspend fun getDecryptedNote(noteId: Long): DecryptedNote? {
        val note = repository.getNoteById(noteId) ?: return null
        return repository.decryptNote(note, _masterPassword.value)
    }
    
    /**
     * Get note by ID (encrypted)
     */
    suspend fun getNoteById(noteId: Long): Note? {
        return repository.getNoteById(noteId)
    }
    
    /**
     * Save note (create or update)
     */
    fun saveNote(
        title: String,
        content: String,
        tags: List<String>,
        isPinned: Boolean = false,
        folder: String = "",
        color: String = "#FFFFFF",
        noteId: Long? = null,
        onComplete: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val id = repository.saveNote(
                title = title,
                content = content,
                tags = tags,
                password = _masterPassword.value,
                isPinned = isPinned,
                folder = folder,
                color = color,
                noteId = noteId
            )
            onComplete(id)
        }
    }
    
    /**
     * Save note with pre-encrypted data (for backup restoration)
     */
    fun saveEncryptedNote(
        encryptedTitle: String,
        encryptedContent: String,
        iv: String,
        titlePlaintext: String,
        contentPreview: String,
        tags: String,
        isPinned: Boolean = false,
        folder: String = "",
        color: String = "#FFFFFF"
    ) {
        viewModelScope.launch {
            repository.saveEncryptedNote(
                encryptedTitle = encryptedTitle,
                encryptedContent = encryptedContent,
                iv = iv,
                titlePlaintext = titlePlaintext,
                contentPreview = contentPreview,
                tags = tags,
                isPinned = isPinned,
                folder = folder,
                color = color
            )
        }
    }
    
    /**
     * Update note folder
     */
    fun updateNoteFolder(noteId: Long, folder: String) {
        viewModelScope.launch {
            val note = repository.getNoteById(noteId)
            if (note != null) {
                val decrypted = repository.decryptNote(note, _masterPassword.value)
                if (decrypted != null) {
                    repository.saveNote(
                        title = decrypted.title,
                        content = decrypted.content,
                        tags = decrypted.tags,
                        password = _masterPassword.value,
                        isPinned = decrypted.isPinned,
                        folder = folder,
                        color = note.color,
                        noteId = noteId
                    )
                }
            }
        }
    }
    
    /**
     * Update note color
     */
    fun updateNoteColor(noteId: Long, color: String) {
        viewModelScope.launch {
            val note = repository.getNoteById(noteId)
            if (note != null) {
                val decrypted = repository.decryptNote(note, _masterPassword.value)
                if (decrypted != null) {
                    repository.saveNote(
                        title = decrypted.title,
                        content = decrypted.content,
                        tags = decrypted.tags,
                        password = _masterPassword.value,
                        isPinned = decrypted.isPinned,
                        folder = note.folder,
                        color = color,
                        noteId = noteId
                    )
                }
            }
        }
    }
    
    /**
     * Get all unique folders
     */
    fun getAllFolders(): StateFlow<List<String>> {
        return _notes.map { notes ->
            notes.map { it.folder }
                .filter { it.isNotEmpty() }
                .distinct()
                .sorted()
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }
    
    /**
     * Delete note
     */
    fun deleteNote(note: Note) {
        viewModelScope.launch {
            _recentlyDeletedNote.value = note
            repository.deleteNote(note)
        }
    }
    
    /**
     * Undo delete
     */
    fun undoDelete() {
        viewModelScope.launch {
            _recentlyDeletedNote.value?.let { note ->
                repository.saveNote(
                    title = note.titlePlaintext,
                    content = note.contentPreview,
                    tags = emptyList(), // Would need to decrypt to get actual content
                    password = _masterPassword.value,
                    isPinned = note.isPinned,
                    noteId = note.id
                )
                _recentlyDeletedNote.value = null
            }
        }
    }
    
    /**
     * Toggle pin status
     */
    fun togglePin(noteId: Long, isPinned: Boolean) {
        viewModelScope.launch {
            repository.togglePin(noteId, !isPinned)
        }
    }
    
    /**
     * Get all notes for backup
     */
    suspend fun getAllNotesForBackup(): List<Note> {
        return repository.getAllNotesForBackup()
    }
}

class NotesViewModelFactory(
    private val repository: NoteRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NotesViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NotesViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
