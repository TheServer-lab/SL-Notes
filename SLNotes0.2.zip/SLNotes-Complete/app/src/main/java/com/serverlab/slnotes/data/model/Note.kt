package com.serverlab.slnotes.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    
    // Encrypted content fields
    val encryptedTitle: String,
    val encryptedContent: String,
    val iv: String, // Initialization Vector for AES encryption
    
    // Searchable plaintext fields (for FTS)
    val titlePlaintext: String,
    val contentPreview: String, // First 200 chars for search
    
    // Organization
    val tags: String, // JSON array of tags
    val isPinned: Boolean = false,
    val folder: String = "", // Folder/Category name
    val color: String = "#FFFFFF", // Note color in hex format
    
    // Timestamps
    val createdAt: Long = Date().time,
    val updatedAt: Long = Date().time,
    
    // Encryption metadata
    val isEncrypted: Boolean = true
)
