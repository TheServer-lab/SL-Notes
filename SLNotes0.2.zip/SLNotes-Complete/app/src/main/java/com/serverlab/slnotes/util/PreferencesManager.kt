package com.serverlab.slnotes.util

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
    
    private val prefs: SharedPreferences = 
        context.getSharedPreferences("sl_notes_prefs", Context.MODE_PRIVATE)
    
    companion object {
        private const val KEY_PASSWORD_SET = "password_set"
        private const val KEY_THEME = "theme"
        private const val KEY_PASSWORD_HASH = "password_hash"
        private const val KEY_FIRST_LAUNCH = "first_launch"
        
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        const val THEME_SYSTEM = "system"
    }
    
    /**
     * Check if this is the first app launch
     */
    fun isFirstLaunch(): Boolean {
        return prefs.getBoolean(KEY_FIRST_LAUNCH, true)
    }
    
    /**
     * Mark first launch as complete
     */
    fun setFirstLaunchComplete() {
        prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply()
    }
    
    /**
     * Check if master password has been set up
     */
    fun isPasswordSet(): Boolean {
        return prefs.getBoolean(KEY_PASSWORD_SET, false)
    }
    
    /**
     * Mark password as set up
     */
    fun setPasswordConfigured(isSet: Boolean) {
        prefs.edit().putBoolean(KEY_PASSWORD_SET, isSet).apply()
    }
    
    /**
     * Save password hash for verification
     */
    fun savePasswordHash(hash: String) {
        prefs.edit().putString(KEY_PASSWORD_HASH, hash).apply()
        setPasswordConfigured(true)
    }
    
    /**
     * Get saved password hash
     */
    fun getPasswordHash(): String? {
        return prefs.getString(KEY_PASSWORD_HASH, null)
    }
    
    /**
     * Verify password against saved hash
     */
    fun verifyPassword(password: String): Boolean {
        val savedHash = getPasswordHash() ?: return false
        val inputHash = EncryptionUtil.hashPassword(password)
        return savedHash == inputHash
    }
    
    /**
     * Get current theme preference
     */
    fun getTheme(): String {
        return prefs.getString(KEY_THEME, THEME_SYSTEM) ?: THEME_SYSTEM
    }
    
    /**
     * Set theme preference
     */
    fun setTheme(theme: String) {
        prefs.edit().putString(KEY_THEME, theme).apply()
    }
    
    /**
     * Clear all preferences (for logout/reset)
     */
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
