package com.serverlab.slnotes.data.dao

import androidx.room.*
import com.serverlab.slnotes.data.model.Note
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    
    @Query("SELECT * FROM notes ORDER BY isPinned DESC, updatedAt DESC")
    fun getAllNotes(): Flow<List<Note>>
    
    @Query("SELECT * FROM notes WHERE id = :noteId")
    suspend fun getNoteById(noteId: Long): Note?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note): Long
    
    @Update
    suspend fun updateNote(note: Note)
    
    @Delete
    suspend fun deleteNote(note: Note)
    
    @Query("DELETE FROM notes WHERE id = :noteId")
    suspend fun deleteNoteById(noteId: Long)
    
    // Full-text search queries
    @Query("""
        SELECT notes.* FROM notes
        JOIN notes_fts ON notes.rowid = notes_fts.rowid
        WHERE notes_fts MATCH :query
        ORDER BY isPinned DESC, updatedAt DESC
    """)
    fun searchNotes(query: String): Flow<List<Note>>
    
    // Filter by tag
    @Query("SELECT * FROM notes WHERE tags LIKE '%' || :tag || '%' ORDER BY isPinned DESC, updatedAt DESC")
    fun getNotesWithTag(tag: String): Flow<List<Note>>
    
    // Sorting queries
    @Query("SELECT * FROM notes ORDER BY isPinned DESC, titlePlaintext ASC")
    fun getNotesSortedByTitle(): Flow<List<Note>>
    
    @Query("SELECT * FROM notes ORDER BY isPinned DESC, createdAt DESC")
    fun getNotesSortedByCreated(): Flow<List<Note>>
    
    @Query("SELECT * FROM notes ORDER BY isPinned DESC, updatedAt DESC")
    fun getNotesSortedByUpdated(): Flow<List<Note>>
    
    // Pin/Unpin
    @Query("UPDATE notes SET isPinned = :isPinned WHERE id = :noteId")
    suspend fun updatePinStatus(noteId: Long, isPinned: Boolean)
    
    // Get all unique tags
    @Query("SELECT DISTINCT tags FROM notes")
    fun getAllTags(): Flow<List<String>>
    
    // Backup - get all notes
    @Query("SELECT * FROM notes")
    suspend fun getAllNotesForBackup(): List<Note>
}
