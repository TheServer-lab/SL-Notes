# SL Notes - Update Changelog

## New Features Added

### 1. 🔐 Password Login on App Restart
**What's New:**
- App now requires password authentication every time it's opened
- Master password is securely stored as a hash using SHA-256
- Uses Android's EncryptedSharedPreferences for secure storage
- Shows error dialog if incorrect password is entered

**Files Created:**
- `app/src/main/java/com/serverlab/slnotes/util/SecurePreferences.kt`

**Files Modified:**
- `app/src/main/java/com/serverlab/slnotes/MainActivity.kt`
  - Added password verification on startup
  - Shows login screen when app is reopened
  - Password setup screen only shown on first launch

**How it Works:**
1. First time: User sets master password → Saved as encrypted hash
2. Every subsequent launch: User must enter password to unlock
3. Password verified against stored hash before granting access
4. Wrong password shows error dialog and prompts retry

---

### 2. 👁️ Note Viewer Screen
**What's New:**
- Dedicated read-only view for notes (no accidental edits!)
- Shows full note content with metadata (creation & edit dates)
- Quick access to edit, pin, and delete functions
- Clean, distraction-free reading experience

**Files Created:**
- `app/src/main/java/com/serverlab/slnotes/ui/screens/NoteViewerScreen.kt`

**Files Modified:**
- `app/src/main/java/com/serverlab/slnotes/ui/navigation/Navigation.kt`
  - Added `NoteViewer` screen route
- `app/src/main/java/com/serverlab/slnotes/MainActivity.kt`
  - Added viewer composable to navigation graph
  - Updated navigation flow: List → Viewer → Editor

**Features:**
- ✅ Full note content display
- ✅ Shows tags as chips
- ✅ Creation and last edited timestamps
- ✅ Pin/unpin toggle in toolbar
- ✅ Edit button (toolbar + FAB)
- ✅ Delete with confirmation dialog
- ✅ Material 3 design

**Navigation Flow:**
- **Before:** Notes List → Click → Opens Editor
- **After:** Notes List → Click → Opens **Viewer** → Click Edit → Opens Editor

---

### 3. ⏱️ Long Press Context Menu
**What's New:**
- Long press on any note card to show quick action menu
- Access view, edit, pin/unpin, and delete without opening the note
- Faster workflow for managing notes

**Files Modified:**
- `app/src/main/java/com/serverlab/slnotes/ui/screens/NotesListScreen.kt`
  - Added `combinedClickable` modifier to note cards
  - Implemented context menu with 4 options
  - Added `onNoteEdit` callback parameter

**Menu Options:**
1. **Open** - View the note (goes to viewer)
2. **Edit** - Edit the note directly
3. **Pin/Unpin** - Toggle pin status
4. **Delete** - Delete with confirmation

---

## Technical Details

### Security Implementation
```kotlin
// SecurePreferences.kt
- Uses EncryptedSharedPreferences (AES256_GCM)
- Passwords hashed with SHA-256 before storage
- Never stores plaintext passwords
- Secure verification on login
```

### New Dependencies
No new dependencies required! Uses existing:
- `androidx.security:security-crypto:1.1.0-alpha06` (already in project)
- All other features use existing Compose/Kotlin libraries

### Code Structure
```
app/src/main/java/com/serverlab/slnotes/
├── ui/
│   ├── screens/
│   │   ├── NoteViewerScreen.kt        [NEW]
│   │   ├── NotesListScreen.kt         [MODIFIED]
│   │   └── PasswordScreen.kt          [EXISTING]
│   └── navigation/
│       └── Navigation.kt              [MODIFIED]
├── util/
│   ├── SecurePreferences.kt           [NEW]
│   ├── EncryptionUtil.kt             [EXISTING]
│   └── BackupUtil.kt                 [EXISTING]
└── MainActivity.kt                    [MODIFIED]
```

---

## User Experience Improvements

### Before Updates:
1. ❌ No password on app restart (security risk)
2. ❌ Click note → immediately in edit mode (risky)
3. ❌ Need to swipe or click note to access options

### After Updates:
1. ✅ Password required every launch (secure)
2. ✅ Click note → view mode → choose to edit (safe)
3. ✅ Long press for instant access to all options (fast)

---

## Testing Checklist

### Password Login
- [ ] First launch: Shows password setup screen
- [ ] Set password: Saves successfully
- [ ] Close and reopen app: Shows login screen
- [ ] Enter correct password: Unlocks successfully
- [ ] Enter wrong password: Shows error dialog
- [ ] Retry with correct password: Works

### Note Viewer
- [ ] Click note from list: Opens in viewer mode
- [ ] View displays: Title, content, tags, dates
- [ ] Pin button: Works in viewer
- [ ] Edit button (toolbar): Opens editor
- [ ] Edit button (FAB): Opens editor
- [ ] Delete button: Shows confirmation
- [ ] Back button: Returns to list

### Long Press Menu
- [ ] Long press note: Menu appears
- [ ] "Open" option: Goes to viewer
- [ ] "Edit" option: Goes to editor
- [ ] "Pin/Unpin" option: Toggles correctly
- [ ] "Delete" option: Deletes note
- [ ] Click outside menu: Menu closes

---

## Migration Guide

### For Existing Users
No data migration needed! Your existing encrypted notes will work exactly as before.

**First Launch After Update:**
1. App will show password setup screen (even if you had notes before)
2. Set a new master password
3. This password will be used to decrypt your existing notes
4. Make sure to use a password you'll remember!

### For New Users
1. First launch: Create master password
2. Create your first note
3. Enjoy the new viewer and long-press features!

---

## Known Limitations

1. **Password Recovery:** 
   - Master password cannot be recovered if forgotten
   - This is by design for maximum security
   - Always remember your password or keep secure backup

2. **Biometric Authentication:**
   - Planned for future update
   - Currently password-only

---

## Future Enhancements (Suggested)

Based on this update, here are some natural next steps:

1. **Biometric Authentication**
   - Fingerprint/Face unlock option
   - Fallback to password if biometric fails

2. **Auto-lock Timer**
   - Lock app after X minutes of inactivity
   - Require password/biometric to unlock

3. **Session Management**
   - Stay logged in until app closed
   - vs. lock on background (user choice)

4. **Rich Text in Viewer**
   - Markdown rendering
   - Syntax highlighting
   - Better formatting display

---

## Credits

**Developer:** Sourasish Das  
**License:** Server-Lab Open-Control License (SOCL) 1.0  
**Version:** 1.1.0 (with login + viewer + long-press)

---

## Questions or Issues?

- **GitHub Issues:** [Report bugs or request features](https://github.com/TheServer-lab/SL-Notes/issues)
- **Discussions:** [Ask questions or share ideas](https://github.com/TheServer-lab/SL-Notes/discussions)

Made with ❤️ and enhanced security!
