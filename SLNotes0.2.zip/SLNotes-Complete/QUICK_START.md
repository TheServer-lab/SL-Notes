# SL Notes - Quick Start Guide

## 🚀 What's New

Your SL Notes app now has these awesome new features:

### 1. 🔐 Login on App Reopen
- Set up password once
- App remembers you've set it up
- Shows login screen when you reopen the app
- Secure password verification

### 2. 🎨 Note Colors
- Long press any note
- Select "Change Color"
- Choose from 20 beautiful colors
- Each note can have its own color!

### 3. 📁 Folders/Categories
- Organize notes into folders
- Long press note → "Move to Folder"
- Create new folders on the fly
- Filter notes by folder

### 4. 🌙 Theme Support
- Go to Settings
- Choose Light, Dark, or System theme
- Theme changes instantly
- Preference is saved

### 5. 👆 Long Press Menu
Long press any note to:
- Edit
- Pin/Unpin
- Change Color
- Move to Folder
- Delete

### 6. 👁️ Note Viewer
- Click a note to VIEW it first
- Read-only display
- Tap Edit button to modify
- Prevents accidental edits

## 📦 New Files

### Core Components
```
app/src/main/java/com/serverlab/slnotes/
├── util/
│   └── PreferencesManager.kt          ← Password & settings storage
├── ui/
│   ├── components/
│   │   ├── ColorPickerDialog.kt      ← Color selection
│   │   ├── FolderPickerDialog.kt     ← Folder management
│   │   └── EnhancedNoteCard.kt       ← Note card with long press
│   └── screens/
│       └── NoteViewerScreen.kt       ← Read-only note viewer
```

### Modified Files
```
app/src/main/java/com/serverlab/slnotes/
├── data/
│   ├── model/
│   │   └── Note.kt                    ← Added: folder, color
│   ├── database/
│   │   └── NotesDatabase.kt          ← Version 1→2
│   └── repository/
│       └── NoteRepository.kt         ← Added: folder methods
├── util/
│   └── EncryptionUtil.kt             ← Added: hashPassword()
└── MainActivity.kt                    ← Login flow integration
```

## 🔨 Integration Steps

### Step 1: Use the New NoteCard
Replace the old `NoteCard` in `NotesListScreen.kt`:

```kotlin
import com.serverlab.slnotes.ui.components.EnhancedNoteCard

// In your LazyColumn items:
EnhancedNoteCard(
    note = note,
    onClick = { onNoteClick(note.id) },
    onEdit = { navController.navigate(Screen.NoteEditor.createRoute(note.id)) },
    onDelete = { onNoteDelete(note) },
    onTogglePin = { onTogglePin(note.id, note.isPinned) },
    onChangeColor = { showColorPickerFor = note.id },
    onMoveToFolder = { showFolderPickerFor = note.id }
)
```

### Step 2: Add Color Picker
```kotlin
var showColorPickerFor by remember { mutableStateOf<Long?>(null) }

if (showColorPickerFor != null) {
    val note = notes.find { it.id == showColorPickerFor }
    if (note != null) {
        ColorPickerDialog(
            currentColor = note.color,
            onColorSelected = { newColor ->
                viewModel.updateNoteColor(note.id, newColor)
            },
            onDismiss = { showColorPickerFor = null }
        )
    }
}
```

### Step 3: Add Folder Picker
```kotlin
var showFolderPickerFor by remember { mutableStateOf<Long?>(null) }
val allFolders by viewModel.allFolders.collectAsState()

if (showFolderPickerFor != null) {
    val note = notes.find { it.id == showFolderPickerFor }
    if (note != null) {
        FolderPickerDialog(
            currentFolder = note.folder,
            allFolders = allFolders,
            onFolderSelected = { newFolder ->
                viewModel.updateNoteFolder(note.id, newFolder)
            },
            onCreateNewFolder = { folderName ->
                // Folder is automatically created when note is moved to it
            },
            onDismiss = { showFolderPickerFor = null }
        )
    }
}
```

### Step 4: Add ViewModel Methods
Add these to `NotesViewModel.kt`:

```kotlin
fun updateNoteColor(noteId: Long, color: String) {
    viewModelScope.launch {
        val note = repository.getNoteById(noteId)
        if (note != null) {
            val decrypted = repository.decryptNote(note, _masterPassword.value)
            repository.saveNote(
                title = decrypted.title,
                content = decrypted.content,
                tags = decrypted.tags,
                password = _masterPassword.value,
                isPinned = note.isPinned,
                folder = note.folder,
                color = color,
                noteId = noteId
            )
        }
    }
}

fun updateNoteFolder(noteId: Long, folder: String) {
    viewModelScope.launch {
        val note = repository.getNoteById(noteId)
        if (note != null) {
            val decrypted = repository.decryptNote(note, _masterPassword.value)
            repository.saveNote(
                title = decrypted.title,
                content = decrypted.content,
                tags = decrypted.tags,
                password = _masterPassword.value,
                isPinned = note.isPinned,
                folder = folder,
                color = note.color,
                noteId = noteId
            )
        }
    }
}

val allFolders: StateFlow<List<String>> = repository.getAllFolders()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
```

## 🎯 Usage Examples

### Example 1: Creating a Colored Note
```kotlin
viewModel.saveNote(
    title = "Meeting Notes",
    content = "Important discussion points...",
    tags = listOf("work"),
    isPinned = false,
    folder = "Work",
    color = "#E3F2FD", // Light blue
    noteId = null
)
```

### Example 2: Filtering by Folder
```kotlin
val workNotes = notes.filter { it.folder == "Work" }
```

### Example 3: Changing Theme
```kotlin
// In Settings
val prefsManager = PreferencesManager(context)
prefsManager.setTheme(PreferencesManager.THEME_DARK)
```

## ⚠️ Important Notes

### Database Migration
- Database version upgraded from 1 to 2
- **Current setting**: `.fallbackToDestructiveMigration()` (LOSES DATA!)
- For production: Implement proper migration (see IMPLEMENTATION_GUIDE.md)

### First Launch After Update
- Users must re-enter password
- All notes keep their content
- New fields get default values

### Testing
1. Test password setup flow
2. Test login after closing app
3. Test long press menu on notes
4. Test color picker
5. Test folder creation and movement
6. Test theme switching

## 🐛 Troubleshooting

### "Cannot find PreferencesManager"
**Fix**: Make sure the file is in `/util/PreferencesManager.kt`

### "Wrong password" error on correct password
**Fix**: Clear app data and set up password again

### Colors not showing
**Fix**: Check that `note.color` has valid hex format (e.g., "#FFFFFF")

### Long press not working
**Fix**: Import `ExperimentalFoundationApi` and use `combinedClickable`

## 📱 Demo Flow

1. **First Launch**
   - Set master password
   - Create some notes
   - Close app

2. **Second Launch**
   - See login screen ✅
   - Enter password
   - See your notes

3. **Use New Features**
   - Long press a note
   - Change its color
   - Move it to a folder
   - Go to Settings
   - Change theme

## 🎨 Available Colors

White, Light Red, Pink, Purple, Deep Purple, Indigo, Blue, Light Blue,
Cyan, Teal, Green, Light Green, Lime, Yellow, Amber, Orange,
Deep Orange, Brown, Grey, Blue Grey

## 📚 Further Reading

- `IMPLEMENTATION_GUIDE.md` - Detailed technical guide
- `README.md` - Original app documentation
- Android Jetpack Compose docs
- Material 3 Design guidelines

---

**Need Help?** Check the implementation guide or review the example code in the components folder!
