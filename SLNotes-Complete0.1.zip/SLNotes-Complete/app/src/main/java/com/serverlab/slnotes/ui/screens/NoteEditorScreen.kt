package com.serverlab.slnotes.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    noteId: Long?,
    initialTitle: String = "",
    initialContent: String = "",
    initialTags: List<String> = emptyList(),
    initialIsPinned: Boolean = false,
    initialFolder: String = "",
    initialColor: String = "#FFFFFF",
    onSave: (String, String, List<String>, Boolean, String, String) -> Unit,
    onBack: () -> Unit
) {
    var title by remember(noteId) { mutableStateOf(initialTitle) }
    var content by remember(noteId) { mutableStateOf(initialContent) }
    var tags by remember(noteId) { mutableStateOf(initialTags) }
    var isPinned by remember(noteId) { mutableStateOf(initialIsPinned) }
    var folder by remember(noteId) { mutableStateOf(initialFolder) }
    var color by remember(noteId) { mutableStateOf(initialColor) }
    var showTagDialog by remember { mutableStateOf(false) }
    var newTag by remember { mutableStateOf("") }

    // Update state when initial values change (for when editing an existing note)
    LaunchedEffect(initialTitle, initialContent, initialTags, initialIsPinned, initialFolder, initialColor) {
        title = initialTitle
        content = initialContent
        tags = initialTags
        isPinned = initialIsPinned
        folder = initialFolder
        color = initialColor
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (noteId == null) "New Note" else "Edit Note") },
                navigationIcon = {
                    IconButton(onClick = {
                        if (title.isNotBlank() || content.isNotBlank()) {
                            onSave(title, content, tags, isPinned, folder, color)
                        }
                        onBack()
                    }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { isPinned = !isPinned }) {
                        Icon(
                            if (isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            "Pin",
                            tint = if (isPinned) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { showTagDialog = true }) {
                        Badge(
                            containerColor = if (tags.isNotEmpty())
                                MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            if (tags.isNotEmpty()) {
                                Text(tags.size.toString())
                            }
                        }
                        Icon(Icons.Default.Label, "Tags")
                    }
                    IconButton(onClick = {
                        if (title.isNotBlank() || content.isNotBlank()) {
                            onSave(title, content, tags, isPinned, folder, color)
                            onBack()
                        }
                    }) {
                        Icon(Icons.Default.Save, "Save")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Title field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Title") },
                textStyle = MaterialTheme.typography.headlineSmall,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Tags display
            if (tags.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    tags.forEach { tag ->
                        AssistChip(
                            onClick = { showTagDialog = true },
                            label = { Text(tag) },
                            trailingIcon = {
                                Icon(
                                    Icons.Default.Close,
                                    "Remove tag",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Content field
            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                placeholder = { Text("Start writing...") },
                textStyle = MaterialTheme.typography.bodyLarge,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default)
            )
        }
    }

    // Tag dialog
    if (showTagDialog) {
        AlertDialog(
            onDismissRequest = { showTagDialog = false },
            title = { Text("Manage Tags") },
            text = {
                Column {
                    // Current tags
                    tags.forEach { tag ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(tag)
                            IconButton(onClick = { tags = tags - tag }) {
                                Icon(Icons.Default.Delete, "Remove")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Add new tag
                    OutlinedTextField(
                        value = newTag,
                        onValueChange = { newTag = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("New tag") },
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    if (newTag.isNotBlank() && !tags.contains(newTag)) {
                                        tags = tags + newTag
                                        newTag = ""
                                    }
                                },
                                enabled = newTag.isNotBlank()
                            ) {
                                Icon(Icons.Default.Add, "Add tag")
                            }
                        },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showTagDialog = false }) {
                    Text("Done")
                }
            }
        )
    }
}