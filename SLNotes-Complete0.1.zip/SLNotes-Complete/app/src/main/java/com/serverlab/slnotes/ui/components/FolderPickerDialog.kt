package com.serverlab.slnotes.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun FolderPickerDialog(
    currentFolder: String,
    allFolders: List<String>,
    onFolderSelected: (String) -> Unit,
    onCreateNewFolder: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Move to Folder") },
        text = {
            Column {
                // No folder option
                ListItem(
                    headlineContent = { Text("No Folder") },
                    leadingContent = {
                        RadioButton(
                            selected = currentFolder.isEmpty(),
                            onClick = {
                                onFolderSelected("")
                                onDismiss()
                            }
                        )
                    },
                    modifier = Modifier.clickable {
                        onFolderSelected("")
                        onDismiss()
                    }
                )
                
                Divider()
                
                // Existing folders
                if (allFolders.isNotEmpty()) {
                    Text(
                        "Folders",
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(16.dp, 8.dp)
                    )
                    
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 200.dp)
                    ) {
                        items(allFolders) { folder ->
                            ListItem(
                                headlineContent = { Text(folder) },
                                leadingContent = {
                                    RadioButton(
                                        selected = currentFolder == folder,
                                        onClick = {
                                            onFolderSelected(folder)
                                            onDismiss()
                                        }
                                    )
                                },
                                trailingContent = {
                                    Icon(Icons.Default.Folder, null)
                                },
                                modifier = Modifier.clickable {
                                    onFolderSelected(folder)
                                    onDismiss()
                                }
                            )
                        }
                    }
                }
                
                Divider()
                
                // Create new folder button
                ListItem(
                    headlineContent = { Text("Create New Folder") },
                    leadingContent = {
                        Icon(Icons.Default.CreateNewFolder, "Create folder")
                    },
                    modifier = Modifier.clickable {
                        showNewFolderDialog = true
                    }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
    
    // New Folder Dialog
    if (showNewFolderDialog) {
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("New Folder") },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Folder Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newFolderName.isNotBlank()) {
                            onCreateNewFolder(newFolderName.trim())
                            onFolderSelected(newFolderName.trim())
                            showNewFolderDialog = false
                            onDismiss()
                        }
                    },
                    enabled = newFolderName.isNotBlank()
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
