package com.serverlab.slnotes.data.repository

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.serverlab.slnotes.data.dao.NoteDao
import com.serverlab.slnotes.data.model.Note
import com.serverlab.slnotes.util.EncryptionUtil
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Date
import javax.crypto.spec.SecretKeySpec

class NoteRepository(private val noteDao: NoteDao) {
    
    private val gson = Gson()
    
    enum class SortBy {
        UPDATED, CREATED, TITLE, PINNED
    }
    
    /**
     * Get all notes with decryption
     */
    fun getAllNotes(sortBy: SortBy = SortBy.UPDATED): Flow<List<Note>> {
        return when (sortBy) {
            SortBy.TITLE -> noteDao.getNotesSortedByTitle()
            SortBy.CREATED -> noteDao.getNotesSortedByCreated()
            SortBy.UPDATED -> noteDao.getNotesSortedByUpdated()
            SortBy.PINNED -> noteDao.getAllNotes()
        }
    }
    
    /**
     * Get a single note by ID
     */
    suspend fun getNoteById(noteId: Long): Note? {
        return noteDao.getNoteById(noteId)
    }
    
    /**
     * Decrypt a note's content
     */
    fun decryptNote(note: Note, password: String): DecryptedNote {
        val key = EncryptionUtil.deriveKeyFromPassword(password)
        val iv = EncryptionUtil.stringToIV(note.iv)
        
        return try {
            val title = EncryptionUtil.decrypt(note.encryptedTitle, key, iv)
            val content = EncryptionUtil.decrypt(note.encryptedContent, key, iv)
            val tags = gson.fromJson<List<String>>(
                note.tags,
                object : TypeToken<List<String>>() {}.type
            ) ?: emptyList()
            
            DecryptedNote(
                id = note.id,
                title = title,
                content = content,
                tags = tags,
                isPinned = note.isPinned,
                folder = note.folder,
                color = note.color,
                createdAt = note.createdAt,
                updatedAt = note.updatedAt,
                isEncrypted = note.isEncrypted
            )
        } catch (e: Exception) {
            // Return error state if decryption fails
            DecryptedNote(
                id = note.id,
                title = "Decryption Failed",
                content = "Unable to decrypt note. Wrong password?",
                tags = emptyList(),
                isPinned = note.isPinned,
                folder = note.folder,
                color = note.color,
                createdAt = note.createdAt,
                updatedAt = note.updatedAt,
                isEncrypted = true,
                decryptionFailed = true
            )
        }
    }
    
    /**
     * Insert or update a note with encryption
     */
    suspend fun saveNote(
        title: String,
        content: String,
        tags: List<String>,
        password: String,
        isPinned: Boolean = false,
        folder: String = "",
        color: String = "#FFFFFF",
        noteId: Long? = null
    ): Long {
        val key = EncryptionUtil.deriveKeyFromPassword(password)
        val iv = EncryptionUtil.generateIV()
        
        val encryptedTitle = EncryptionUtil.encrypt(title, key, iv)
        val encryptedContent = EncryptionUtil.encrypt(content, key, iv)
        val ivString = EncryptionUtil.ivToString(iv)
        
        val note = Note(
            id = noteId ?: 0,
            encryptedTitle = encryptedTitle,
            encryptedContent = encryptedContent,
            iv = ivString,
            titlePlaintext = title,
            contentPreview = EncryptionUtil.generateContentPreview(content),
            tags = gson.toJson(tags),
            isPinned = isPinned,
            folder = folder,
            color = color,
            createdAt = if (noteId == null) Date().time else 0,
            updatedAt = Date().time,
            isEncrypted = true
        )
        
        return if (noteId == null) {
            noteDao.insertNote(note)
        } else {
            noteDao.updateNote(note)
            noteId
        }
    }
    
    /**
     * Delete a note
     */
    suspend fun deleteNote(note: Note) {
        noteDao.deleteNote(note)
    }
    
    /**
     * Delete note by ID
     */
    suspend fun deleteNoteById(noteId: Long) {
        noteDao.deleteNoteById(noteId)
    }
    
    /**
     * Toggle pin status
     */
    suspend fun togglePin(noteId: Long, isPinned: Boolean) {
        noteDao.updatePinStatus(noteId, isPinned)
    }
    
    /**
     * Search notes using FTS
     */
    fun searchNotes(query: String): Flow<List<Note>> {
        // Convert query to FTS format (add wildcards)
        val ftsQuery = query.split(" ")
            .joinToString(" ") { "$it*" }
        return noteDao.searchNotes(ftsQuery)
    }
    
    /**
     * Filter notes by tag
     */
    fun getNotesWithTag(tag: String): Flow<List<Note>> {
        return noteDao.getNotesWithTag(tag)
    }
    
    /**
     * Get all unique tags
     */
    fun getAllTags(): Flow<List<String>> {
        return noteDao.getAllTags().map { tagJsonList ->
            tagJsonList.flatMap { tagJson ->
                gson.fromJson<List<String>>(
                    tagJson,
                    object : TypeToken<List<String>>() {}.type
                ) ?: emptyList()
            }.distinct().sorted()
        }
    }
    
    /**
     * Get all unique folders
     */
    fun getAllFolders(): Flow<List<String>> {
        return noteDao.getAllNotes().map { notes ->
            notes.map { it.folder }
                .filter { it.isNotBlank() }
                .distinct()
                .sorted()
        }
    }
    
    /**
     * Filter notes by folder
     */
    fun getNotesByFolder(folder: String): Flow<List<Note>> {
        return noteDao.getAllNotes().map { notes ->
            notes.filter { it.folder == folder }
        }
    }
    
    /**
     * Get all notes for backup
     */
    suspend fun getAllNotesForBackup(): List<Note> {
        return noteDao.getAllNotesForBackup()
    }
}

/**
 * Decrypted note data class for UI
 */
data class DecryptedNote(
    val id: Long,
    val title: String,
    val content: String,
    val tags: List<String>,
    val isPinned: Boolean,
    val folder: String = "",
    val color: String = "#FFFFFF",
    val createdAt: Long,
    val updatedAt: Long,
    val isEncrypted: Boolean,
    val decryptionFailed: Boolean = false
)
