package com.serverlab.slnotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.serverlab.slnotes.data.database.NotesDatabase
import com.serverlab.slnotes.data.model.Note
import com.serverlab.slnotes.data.repository.NoteRepository
import com.serverlab.slnotes.ui.navigation.Screen
import com.serverlab.slnotes.ui.screens.*
import com.serverlab.slnotes.ui.theme.SLNotesTheme
import com.serverlab.slnotes.ui.viewmodel.NotesViewModel
import com.serverlab.slnotes.ui.viewmodel.NotesViewModelFactory
import com.serverlab.slnotes.util.PreferencesManager
import com.serverlab.slnotes.util.EncryptionUtil
import kotlinx.coroutines.launch

// Data class for note viewer
data class NoteViewData(
    val title: String,
    val content: String,
    val tags: List<String>,
    val isPinned: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize database and repository
        val database = NotesDatabase.getDatabase(applicationContext)
        val repository = NoteRepository(database.noteDao())
        val prefsManager = PreferencesManager(applicationContext)
        
        setContent {
            val prefsManager = PreferencesManager(applicationContext)
            val currentTheme = remember { mutableStateOf(prefsManager.getTheme()) }
            
            SLNotesTheme(themePreference = currentTheme.value) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SLNotesApp(repository, prefsManager)
                }
            }
        }
    }
}

@Composable
fun SLNotesApp(repository: NoteRepository, prefsManager: PreferencesManager) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val navController = rememberNavController()
    val viewModel: NotesViewModel = viewModel(
        factory = NotesViewModelFactory(repository)
    )
    
    // Theme state
    var currentTheme by remember { mutableStateOf(prefsManager.getTheme()) }
    
    val notes by viewModel.displayedNotes.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedTags by viewModel.selectedTags.collectAsState()
    val allTags by viewModel.allTags.collectAsState()
    val sortBy by viewModel.sortBy.collectAsState()
    val recentlyDeletedNote by viewModel.recentlyDeletedNote.collectAsState()
    val masterPassword by viewModel.masterPassword.collectAsState()
    
    val coroutineScope = rememberCoroutineScope()
    
    // Check first launch and password setup
    val isFirstLaunch = remember { prefsManager.isFirstLaunch() }
    val isPasswordSet = remember { com.serverlab.slnotes.util.SecurePreferences.isPasswordSet(context) }
    
    val startDestination = when {
        isFirstLaunch -> "welcome"
        isPasswordSet -> Screen.PasswordLogin.route
        else -> Screen.PasswordSetup.route
    }
    
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        // Welcome Screen
        composable("welcome") {
            WelcomeScreen(
                onGetStarted = {
                    prefsManager.setFirstLaunchComplete()
                    navController.navigate(Screen.PasswordSetup.route) {
                        popUpTo("welcome") { inclusive = true }
                    }
                }
            )
        }
        // Password Setup
        composable(Screen.PasswordSetup.route) {
            PasswordSetupScreen(
                onPasswordSet = { password ->
                    com.serverlab.slnotes.util.SecurePreferences.saveMasterPassword(context, password)
                    viewModel.setMasterPassword(password)
                    navController.navigate(Screen.NotesList.route) {
                        popUpTo(Screen.PasswordSetup.route) { inclusive = true }
                    }
                }
            )
        }
        
        // Password Login
        composable(Screen.PasswordLogin.route) {
            var showError by remember { mutableStateOf(false) }
            
            PasswordLoginScreen(
                onPasswordEntered = { password ->
                    if (com.serverlab.slnotes.util.SecurePreferences.verifyPassword(context, password)) {
                        viewModel.setMasterPassword(password)
                        showError = false
                        navController.navigate(Screen.NotesList.route) {
                            popUpTo(Screen.PasswordLogin.route) { inclusive = true }
                        }
                    } else {
                        showError = true
                    }
                }
            )
            
            if (showError) {
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { showError = false },
                    icon = {
                        androidx.compose.material3.Icon(
                            androidx.compose.material.icons.Icons.Default.Warning,
                            contentDescription = null,
                            tint = androidx.compose.material3.MaterialTheme.colorScheme.error
                        )
                    },
                    title = { androidx.compose.material3.Text("Incorrect Password") },
                    text = { androidx.compose.material3.Text("The password you entered is incorrect. Please try again.") },
                    confirmButton = {
                        androidx.compose.material3.TextButton(onClick = { showError = false }) {
                            androidx.compose.material3.Text("OK")
                        }
                    }
                )
            }
        }
        
        // Notes List
        composable(Screen.NotesList.route) {
            val allFolders by viewModel.getAllFolders().collectAsState()
            
            NotesListScreen(
                notes = notes,
                searchQuery = searchQuery,
                selectedTags = selectedTags,
                allTags = allTags,
                allFolders = allFolders,
                sortBy = sortBy,
                recentlyDeletedNote = recentlyDeletedNote,
                onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                onToggleTag = { viewModel.toggleTagFilter(it) },
                onClearTags = { viewModel.clearTagFilters() },
                onSortChange = { viewModel.setSortBy(it) },
                onNoteClick = { noteId ->
                    navController.navigate(Screen.NoteViewer.createRoute(noteId))
                },
                onNoteEdit = { noteId ->
                    navController.navigate(Screen.NoteEditor.createRoute(noteId))
                },
                onNoteDelete = { note ->
                    viewModel.deleteNote(note)
                },
                onUndoDelete = { viewModel.undoDelete() },
                onTogglePin = { noteId, isPinned ->
                    viewModel.togglePin(noteId, isPinned)
                },
                onUpdateFolder = { noteId, folder ->
                    viewModel.updateNoteFolder(noteId, folder)
                },
                onUpdateColor = { noteId, color ->
                    viewModel.updateNoteColor(noteId, color)
                },
                onNewNoteClick = {
                    navController.navigate(Screen.NoteEditor.createRoute(null))
                },
                onMenuClick = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }
        
        // Note Viewer
        composable(
            route = Screen.NoteViewer.route,
            arguments = listOf(
                navArgument("noteId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val noteIdString = backStackEntry.arguments?.getString("noteId")
            val noteId = noteIdString?.toLongOrNull()
            
            // Use derivedStateOf to load note data
            var noteData by remember { mutableStateOf<NoteViewData?>(null) }
            var isLoading by remember { mutableStateOf(true) }
            
            LaunchedEffect(noteId) {
                isLoading = true
                if (noteId != null) {
                    // Get decrypted content directly
                    val decryptedNote = viewModel.getDecryptedNote(noteId)
                    if (decryptedNote != null) {
                        noteData = NoteViewData(
                            title = decryptedNote.title,
                            content = decryptedNote.content,
                            tags = decryptedNote.tags,
                            isPinned = decryptedNote.isPinned,
                            createdAt = decryptedNote.createdAt,
                            updatedAt = decryptedNote.updatedAt
                        )
                    }
                }
                isLoading = false
            }
            
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                noteId != null && noteData != null -> {
                    NoteViewerScreen(
                        noteId = noteId,
                        title = noteData!!.title,
                        content = noteData!!.content,
                        tags = noteData!!.tags,
                        isPinned = noteData!!.isPinned,
                        createdAt = noteData!!.createdAt,
                        updatedAt = noteData!!.updatedAt,
                        onEdit = {
                            navController.navigate(Screen.NoteEditor.createRoute(noteId))
                        },
                        onDelete = {
                            // Find the actual note object for deletion
                            coroutineScope.launch {
                                val note = viewModel.getNoteById(noteId)
                                note?.let { viewModel.deleteNote(it) }
                                navController.popBackStack()
                            }
                        },
                        onTogglePin = {
                            viewModel.togglePin(noteId, noteData!!.isPinned)
                        },
                        onBack = {
                            navController.popBackStack()
                        }
                    )
                }
                else -> {
                    // Note not found
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Icon(
                                Icons.Default.Error,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.error
                            )
                            Text(
                                "Note not found",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Button(onClick = { navController.popBackStack() }) {
                                Text("Go Back")
                            }
                        }
                    }
                }
            }
        }
        
        // Note Editor
        composable(
            route = Screen.NoteEditor.route,
            arguments = listOf(
                navArgument("noteId") {
                    type = NavType.StringType
                    nullable = true
                }
            )
        ) { backStackEntry ->
            val noteIdString = backStackEntry.arguments?.getString("noteId")
            val noteId = if (noteIdString == "new") null else noteIdString?.toLongOrNull()
            
            var initialTitle by remember { mutableStateOf("") }
            var initialContent by remember { mutableStateOf("") }
            var initialTags by remember { mutableStateOf<List<String>>(emptyList()) }
            var initialIsPinned by remember { mutableStateOf(false) }
            var initialFolder by remember { mutableStateOf("") }
            var initialColor by remember { mutableStateOf("#FFFFFF") }
            
            LaunchedEffect(noteId) {
                if (noteId != null) {
                    val note = notes.find { it.id == noteId }
                    val decryptedNote = viewModel.getDecryptedNote(noteId)
                    if (decryptedNote != null && note != null) {
                        initialTitle = decryptedNote.title
                        initialContent = decryptedNote.content
                        initialTags = decryptedNote.tags
                        initialIsPinned = decryptedNote.isPinned
                        initialFolder = note.folder
                        initialColor = note.color
                    }
                }
            }
            
            NoteEditorScreen(
                noteId = noteId,
                initialTitle = initialTitle,
                initialContent = initialContent,
                initialTags = initialTags,
                initialIsPinned = initialIsPinned,
                initialFolder = initialFolder,
                initialColor = initialColor,
                onSave = { title, content, tags, isPinned, folder, color ->
                    if (title.isNotBlank() || content.isNotBlank()) {
                        viewModel.saveNote(
                            title = title,
                            content = content,
                            tags = tags,
                            isPinned = isPinned,
                            folder = folder,
                            color = color,
                            noteId = noteId
                        )
                    }
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }
        
        // Settings
        composable(Screen.Settings.route) {
            SettingsScreen(
                currentTheme = currentTheme,
                onThemeChange = { theme ->
                    prefsManager.setTheme(theme)
                    currentTheme = theme
                },
                onBack = { navController.popBackStack() },
                onCreateBackup = {
                    // TODO: Implement backup creation
                },
                onRestoreBackup = {
                    // TODO: Implement backup restoration
                },
                onExportAllNotes = {
                    // TODO: Implement export all notes
                }
            )
        }
    }
}
