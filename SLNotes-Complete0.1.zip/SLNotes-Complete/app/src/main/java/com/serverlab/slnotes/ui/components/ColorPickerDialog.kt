package com.serverlab.slnotes.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ColorPickerDialog(
    currentColor: String,
    onColorSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = listOf(
        "#FFFFFF" to "White",
        "#FFEBEE" to "Light Red",
        "#FCE4EC" to "Pink",
        "#F3E5F5" to "Purple",
        "#EDE7F6" to "Deep Purple",
        "#E8EAF6" to "Indigo",
        "#E3F2FD" to "Blue",
        "#E1F5FE" to "Light Blue",
        "#E0F7FA" to "Cyan",
        "#E0F2F1" to "Teal",
        "#E8F5E9" to "Green",
        "#F1F8E9" to "Light Green",
        "#F9FBE7" to "Lime",
        "#FFFDE7" to "Yellow",
        "#FFF8E1" to "Amber",
        "#FFF3E0" to "Orange",
        "#FBE9E7" to "Deep Orange",
        "#EFEBE9" to "Brown",
        "#FAFAFA" to "Grey",
        "#ECEFF1" to "Blue Grey"
    )
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose Note Color") },
        text = {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.height(300.dp)
            ) {
                items(colors) { (hex, name) ->
                    val color = try {
                        Color(android.graphics.Color.parseColor(hex))
                    } catch (e: Exception) {
                        Color.White
                    }
                    
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (hex == currentColor) 3.dp else 1.dp,
                                color = if (hex == currentColor)
                                    MaterialTheme.colorScheme.primary
                                else
                                    Color.Gray,
                                shape = CircleShape
                            )
                            .clickable {
                                onColorSelected(hex)
                                onDismiss()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        // Empty content - Box is used just for the colored circle
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
