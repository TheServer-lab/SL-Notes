package com.serverlab.slnotes.ui.navigation

sealed class Screen(val route: String) {
    object PasswordSetup : Screen("password_setup")
    object PasswordLogin : Screen("password_login")
    object NotesList : Screen("notes_list")
    object NoteViewer : Screen("note_viewer/{noteId}") {
        fun createRoute(noteId: Long) = "note_viewer/$noteId"
    }
    object NoteEditor : Screen("note_editor/{noteId}") {
        fun createRoute(noteId: Long?) = if (noteId != null) "note_editor/$noteId" else "note_editor/new"
    }
    object Settings : Screen("settings")
}
