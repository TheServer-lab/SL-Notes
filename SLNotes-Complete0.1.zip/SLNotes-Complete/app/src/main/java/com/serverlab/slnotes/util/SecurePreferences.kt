package com.serverlab.slnotes.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import java.security.MessageDigest

object SecurePreferences {
    private const val PREFS_FILENAME = "sl_notes_secure_prefs"
    private const val KEY_PASSWORD_HASH = "password_hash"
    
    private fun getPreferences(context: Context): SharedPreferences {
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        
        return EncryptedSharedPreferences.create(
            PREFS_FILENAME,
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
    
    /**
     * Hash password using SHA-256
     */
    private fun hashPassword(password: String): String {
        val bytes = password.toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        return digest.fold("") { str, it -> str + "%02x".format(it) }
    }
    
    /**
     * Save master password (hashed)
     */
    fun saveMasterPassword(context: Context, password: String) {
        val hash = hashPassword(password)
        getPreferences(context).edit()
            .putString(KEY_PASSWORD_HASH, hash)
            .apply()
    }
    
    /**
     * Check if password is set
     */
    fun isPasswordSet(context: Context): Boolean {
        return getPreferences(context).contains(KEY_PASSWORD_HASH)
    }
    
    /**
     * Verify password
     */
    fun verifyPassword(context: Context, password: String): Boolean {
        val storedHash = getPreferences(context).getString(KEY_PASSWORD_HASH, null)
        val inputHash = hashPassword(password)
        return storedHash == inputHash
    }
    
    /**
     * Clear all data (for reset/logout)
     */
    fun clear(context: Context) {
        getPreferences(context).edit().clear().apply()
    }
}
