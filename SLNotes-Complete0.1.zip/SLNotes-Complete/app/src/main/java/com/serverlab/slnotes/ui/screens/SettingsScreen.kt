package com.serverlab.slnotes.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onCreateBackup: () -> Unit,
    onRestoreBackup: () -> Unit,
    onExportAllNotes: () -> Unit,
    currentTheme: String = "system",
    onThemeChange: (String) -> Unit = {}
) {
    var showLicense by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            // Appearance Section
            Text(
                "Appearance",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp)
            )

            ListItem(
                headlineContent = { Text("Theme") },
                supportingContent = { 
                    Text(when (currentTheme) {
                        "light" -> "Light"
                        "dark" -> "Dark"
                        else -> "System Default"
                    })
                },
                leadingContent = { Icon(Icons.Default.Palette, null) },
                modifier = Modifier.clickable { showThemeDialog = true }
            )

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            // Backup & Export Section
            Text(
                "Backup & Export",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp)
            )

            ListItem(
                headlineContent = { Text("Create Encrypted Backup") },
                supportingContent = { Text("Export all notes as encrypted .sln file") },
                leadingContent = { Icon(Icons.Default.Backup, null) },
                modifier = Modifier.clickable(onClick = onCreateBackup)
            )

            ListItem(
                headlineContent = { Text("Restore from Backup") },
                supportingContent = { Text("Import notes from .sln backup file") },
                leadingContent = { Icon(Icons.Default.Restore, null) },
                modifier = Modifier.clickable(onClick = onRestoreBackup)
            )

            ListItem(
                headlineContent = { Text("Export All as Text") },
                supportingContent = { Text("Export each note as separate .txt file") },
                leadingContent = { Icon(Icons.Default.Output, null) },
                modifier = Modifier.clickable(onClick = onExportAllNotes)
            )

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            // About Section
            Text(
                "About",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp)
            )

            ListItem(
                headlineContent = { Text("SL Notes") },
                supportingContent = { Text("Version 1.0 - Secure note-taking app") },
                leadingContent = { Icon(Icons.Default.Info, null) }
            )

            ListItem(
                headlineContent = { Text("GitHub Repository") },
                supportingContent = { Text("View source code and contribute") },
                leadingContent = { Icon(Icons.Default.Code, null) },
                modifier = Modifier.clickable {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/TheServer-lab/SL-Notes"))
                    context.startActivity(intent)
                }
            )

            ListItem(
                headlineContent = { Text("License") },
                supportingContent = { Text("Server-Lab Open-Control License (SOCL) 1.0") },
                leadingContent = { Icon(Icons.Default.Description, null) },
                modifier = Modifier.clickable { showLicense = true }
            )

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            // Security Section
            Text(
                "Security",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Security,
                            null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Encryption Active",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "• AES-256 encryption\n• PBKDF2 key derivation\n• Unique IV per note\n• FTS searchable without decryption",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
    }

    // Theme Selection Dialog
    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            icon = { Icon(Icons.Default.Palette, null) },
            title = { Text("Choose Theme") },
            text = {
                Column {
                    ThemeOption(
                        title = "Light",
                        description = "Always use light theme",
                        isSelected = currentTheme == "light",
                        onClick = {
                            onThemeChange("light")
                            showThemeDialog = false
                        }
                    )
                    ThemeOption(
                        title = "Dark",
                        description = "Always use dark theme",
                        isSelected = currentTheme == "dark",
                        onClick = {
                            onThemeChange("dark")
                            showThemeDialog = false
                        }
                    )
                    ThemeOption(
                        title = "System Default",
                        description = "Follow system theme",
                        isSelected = currentTheme == "system",
                        onClick = {
                            onThemeChange("system")
                            showThemeDialog = false
                        }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // License Dialog
    if (showLicense) {
        AlertDialog(
            onDismissRequest = { showLicense = false },
            title = { Text("Server-Lab Open-Control License (SOCL) 1.0") },
            text = {
                Text(
                    text = """Server-Lab Open-Control License (SOCL) 1.0
====================================
Copyright (c) 2025 Sourasish Das

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

1. Attribution.
   The original copyright notice and this license text must be retained in
   all copies or substantial portions of the Software. If you distribute
   compiled or packaged forms of the Software, you must include the copyright
   notice and a copy of this license in a file distributed with those forms.

2. Open-source grant.
   The rights granted in this license are intended to be open-source in nature:
   recipients may use, study, modify, and redistribute the Software under the
   terms set forth herein.

3. Ownership and control.
   Copyright and all intellectual property rights in the Software are and remain
   the exclusive property of the Copyright Owner named above. The Copyright
   Owner retains sole authority to relicense, alter, or otherwise change the
   licensing terms that apply to future distributions of the Software.

4. License changes; effective date.
   The Copyright Owner may change or replace this license at any time and
   without notice. Any such change applies only to versions or distributions
   of the Software that the Copyright Owner explicitly distributes after the
   change takes effect. Copies of the Software already distributed by the
   Copyright Owner under a prior version of this license remain governed by
   the terms under which those copies were originally distributed.

5. No trademark rights.
   This license does not grant any rights to use the Copyright Owner's trade
   names, trademarks, service marks, or logos.

6. No warranty.
   THE SOFTWARE IS PROVIDED "AS IS" AND THE COPYRIGHT OWNER DISCLAIMS ALL
   WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
   WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
   NON-INFRINGEMENT. USE OF THE SOFTWARE IS AT YOUR OWN RISK.

7. Limitation of liability.
   IN NO EVENT SHALL THE COPYRIGHT OWNER BE LIABLE FOR ANY CLAIM, DAMAGES OR
   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
   DEALINGS IN THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

8. Contributor submissions.
   By submitting a contribution to the project, a contributor grants the
   Copyright Owner a perpetual, irrevocable, worldwide, royalty-free,
   transferable license to use, reproduce, modify, distribute, sublicense,
   and otherwise exploit the contribution as part of the Software.

9. Termination.
   This license and the rights granted hereunder will terminate automatically
   if you fail to comply with any term of this license.

10. Governing law.
    This license does not select a governing law.

[END OF LICENSE]""",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace
                    ),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            },
            confirmButton = {
                TextButton(onClick = { showLicense = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun ThemeOption(
    title: String,
    description: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(description) },
        leadingContent = {
            RadioButton(
                selected = isSelected,
                onClick = onClick
            )
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}