package com.serverlab.slnotes.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.serverlab.slnotes.data.model.Note
import com.serverlab.slnotes.data.repository.NoteRepository
import com.serverlab.slnotes.ui.components.ColorPickerDialog
import com.serverlab.slnotes.ui.components.FolderPickerDialog
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun NotesListScreen(
    notes: List<Note>,
    searchQuery: String,
    selectedTags: Set<String>,
    allTags: List<String>,
    allFolders: List<String>,
    sortBy: NoteRepository.SortBy,
    recentlyDeletedNote: Note?,
    onSearchQueryChange: (String) -> Unit,
    onToggleTag: (String) -> Unit,
    onClearTags: () -> Unit,
    onSortChange: (NoteRepository.SortBy) -> Unit,
    onNoteClick: (Long) -> Unit,
    onNoteEdit: (Long) -> Unit,
    onNoteDelete: (Note) -> Unit,
    onUndoDelete: () -> Unit,
    onTogglePin: (Long, Boolean) -> Unit,
    onUpdateFolder: (Long, String) -> Unit,
    onUpdateColor: (Long, String) -> Unit,
    onNewNoteClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    var showSortMenu by remember { mutableStateOf(false) }
    var showTagFilter by remember { mutableStateOf(false) }
    
    // Auto-hide undo snackbar
    LaunchedEffect(recentlyDeletedNote) {
        if (recentlyDeletedNote != null) {
            delay(5000)
            // Could clear the deleted note here if needed
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SL Notes") },
                actions = {
                    IconButton(onClick = { showTagFilter = !showTagFilter }) {
                        Badge(
                            containerColor = if (selectedTags.isNotEmpty()) 
                                MaterialTheme.colorScheme.primary 
                            else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            if (selectedTags.isNotEmpty()) {
                                Text(selectedTags.size.toString())
                            }
                        }
                        Icon(Icons.Default.FilterList, "Filter by tags")
                    }
                    IconButton(onClick = { showSortMenu = true }) {
                        Icon(Icons.Default.Sort, "Sort")
                    }
                    
                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Last Updated") },
                            onClick = {
                                onSortChange(NoteRepository.SortBy.UPDATED)
                                showSortMenu = false
                            },
                            leadingIcon = {
                                if (sortBy == NoteRepository.SortBy.UPDATED) {
                                    Icon(Icons.Default.Check, null)
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Date Created") },
                            onClick = {
                                onSortChange(NoteRepository.SortBy.CREATED)
                                showSortMenu = false
                            },
                            leadingIcon = {
                                if (sortBy == NoteRepository.SortBy.CREATED) {
                                    Icon(Icons.Default.Check, null)
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Title") },
                            onClick = {
                                onSortChange(NoteRepository.SortBy.TITLE)
                                showSortMenu = false
                            },
                            leadingIcon = {
                                if (sortBy == NoteRepository.SortBy.TITLE) {
                                    Icon(Icons.Default.Check, null)
                                }
                            }
                        )
                    }
                    
                    IconButton(onClick = onMenuClick) {
                        Icon(Icons.Default.MoreVert, "Menu")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewNoteClick) {
                Icon(Icons.Default.Add, "New Note")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = { Text("Search notes...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, "Clear")
                        }
                    }
                },
                singleLine = true
            )
            
            // Tag filter chips
            AnimatedVisibility(visible = showTagFilter && allTags.isNotEmpty()) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Filter by tags",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (selectedTags.isNotEmpty()) {
                            TextButton(onClick = onClearTags) {
                                Text("Clear all")
                            }
                        }
                    }
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        allTags.take(5).forEach { tag ->
                            FilterChip(
                                selected = selectedTags.contains(tag),
                                onClick = { onToggleTag(tag) },
                                label = { Text(tag) }
                            )
                        }
                    }
                }
            }
            
            // Notes list
            if (notes.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Note,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            if (searchQuery.isNotEmpty() || selectedTags.isNotEmpty()) {
                                "No notes found"
                            } else {
                                "No notes yet"
                            },
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(
                        items = notes,
                        key = { it.id }
                    ) { note ->
                        NoteCard(
                            note = note,
                            allFolders = allFolders,
                            onClick = { onNoteClick(note.id) },
                            onEdit = { onNoteEdit(note.id) },
                            onDelete = { onNoteDelete(note) },
                            onTogglePin = { onTogglePin(note.id, note.isPinned) },
                            onUpdateFolder = { folder -> onUpdateFolder(note.id, folder) },
                            onUpdateColor = { color -> onUpdateColor(note.id, color) },
                            modifier = Modifier.animateItemPlacement()
                        )
                    }
                }
            }
        }
        
        // Undo delete snackbar
        if (recentlyDeletedNote != null) {
            Snackbar(
                modifier = Modifier.padding(16.dp),
                action = {
                    TextButton(onClick = onUndoDelete) {
                        Text("UNDO")
                    }
                }
            ) {
                Text("Note deleted")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun NoteCard(
    note: Note,
    allFolders: List<String>,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onTogglePin: () -> Unit,
    onEdit: () -> Unit,
    onUpdateFolder: (String) -> Unit,
    onUpdateColor: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    var showFolderDialog by remember { mutableStateOf(false) }
    var showColorDialog by remember { mutableStateOf(false) }
    
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { dismissValue ->
            if (dismissValue == SwipeToDismissBoxValue.EndToStart) {
                onDelete()
                true
            } else {
                false
            }
        }
    )
    
    SwipeToDismissBox(
        state = dismissState,
        modifier = modifier,
        enableDismissFromStartToEnd = false,
        backgroundContent = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.errorContainer),
                contentAlignment = Alignment.CenterEnd
            ) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = "Delete",
                    modifier = Modifier.padding(16.dp),
                    tint = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
    ) {
        val cardColor = try {
            Color(android.graphics.Color.parseColor(note.color))
        } catch (e: Exception) {
            MaterialTheme.colorScheme.surface
        }
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = cardColor
            )
        ) {
            Box {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onClick)
                        .combinedClickable(
                            onClick = onClick,
                            onLongClick = { showMenu = true }
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = note.titlePlaintext,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (note.isPinned) {
                            Icon(
                                Icons.Default.PushPin,
                                contentDescription = "Pinned",
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = note.contentPreview,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = SimpleDateFormat("MMM dd, yyyy", Locale.US).format(Date(note.updatedAt)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        if (note.folder.isNotEmpty()) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Folder,
                                    contentDescription = "Folder",
                                    modifier = Modifier.size(14.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = note.folder,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                
                // Context menu on long press
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Open") },
                        onClick = {
                            showMenu = false
                            onClick()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Visibility, null)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Edit") },
                        onClick = {
                            showMenu = false
                            onEdit()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Edit, null)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(if (note.isPinned) "Unpin" else "Pin") },
                        onClick = {
                            showMenu = false
                            onTogglePin()
                        },
                        leadingIcon = {
                            Icon(
                                if (note.isPinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                                null
                            )
                        }
                    )
                    Divider()
                    DropdownMenuItem(
                        text = { Text("Move to Folder") },
                        onClick = {
                            showMenu = false
                            showFolderDialog = true
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Folder, null)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Change Color") },
                        onClick = {
                            showMenu = false
                            showColorDialog = true
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Palette, null)
                        }
                    )
                    Divider()
                    DropdownMenuItem(
                        text = { Text("Delete") },
                        onClick = {
                            showMenu = false
                            onDelete()
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Delete,
                                null,
                                tint = MaterialTheme.colorScheme.error
                            )
                        },
                        colors = MenuDefaults.itemColors(
                            textColor = MaterialTheme.colorScheme.error
                        )
                    )
                }
            }
        }
    }
    
    // Folder picker dialog
    if (showFolderDialog) {
        FolderPickerDialog(
            currentFolder = note.folder,
            allFolders = allFolders,
            onFolderSelected = { folder ->
                onUpdateFolder(folder)
                showFolderDialog = false
            },
            onCreateNewFolder = { /* Folder creation handled in dialog */ },
            onDismiss = { showFolderDialog = false }
        )
    }
    
    // Color picker dialog
    if (showColorDialog) {
        ColorPickerDialog(
            currentColor = note.color,
            onColorSelected = { color ->
                onUpdateColor(color)
                showColorDialog = false
            },
            onDismiss = { showColorDialog = false }
        )
    }
}
