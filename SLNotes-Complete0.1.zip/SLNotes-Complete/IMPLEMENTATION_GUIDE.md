# SL Notes - New Features Implementation Guide

## Features Added

### 1. ✅ Login Screen on App Reopen
- Added `PreferencesManager` for persistent password storage
- Password hash is saved securely
- App shows login screen when reopened after initial setup
- Password verification on login

### 2. ✅ Note Colors & Folders
- Added `color` field to Note model (stores hex color)
- Added `folder` field to Note model (category/folder name)
- Database version bumped to v2 with migration support

### 3. ✅ Long Press Menu on Notes
- Long press note cards to show context menu
- Options: Edit, Delete, Change Color, Move to Folder, Pin/Unpin

### 4. ✅ Theme Support  
- Light/Dark/System theme options
- Theme preference saved in PreferencesManager
- Dynamic theme switching without app restart

### 5. ✅ Note Viewer Screen
- Read-only view when clicking notes
- Shows full content, metadata, tags
- Edit button to switch to editor mode

## Database Changes

### Note Model Updates
```kotlin
@Entity(tableName = "notes")
data class Note(
    // ... existing fields ...
    val folder: String = "",      // NEW
    val color: String = "#FFFFFF", // NEW
)
```

### Database Migration
- Version: 1 → 2
- Migration strategy: fallbackToDestructiveMigration (for development)
- Production should use proper migration

## New Files Created

### 1. `/util/PreferencesManager.kt`
Handles all app preferences:
- Password setup status
- Password hash storage/verification
- Theme preferences
- Persistent settings

### 2. `/ui/screens/NoteViewerScreen.kt`
Read-only note viewer with:
- Full content display
- Metadata (creation/edit dates)
- Pin toggle
- Edit and Delete actions

## Key Code Changes

### MainActivity.kt
```kotlin
// Initialize PreferencesManager
val prefsManager = PreferencesManager(applicationContext)

// Check password state on startup
val isPasswordSet = remember { prefsManager.isPasswordSet() }
val startDestination = if (isPasswordSet) 
    Screen.PasswordLogin.route 
else 
    Screen.PasswordSetup.route

// Password Setup - save hash
onPasswordSet = { password ->
    val hash = EncryptionUtil.hashPassword(password)
    prefsManager.savePasswordHash(hash)
    viewModel.setMasterPassword(password)
}

// Password Login - verify hash
onPasswordEntered = { password ->
    if (prefsManager.verifyPassword(password)) {
        viewModel.setMasterPassword(password)
        // Navigate to notes list
    } else {
        // Show error
    }
}
```

### NoteRepository.kt Updates
```kotlin
// Updated saveNote signature
suspend fun saveNote(
    title: String,
    content: String,
    tags: List<String>,
    password: String,
    isPinned: Boolean = false,
    folder: String = "",        // NEW
    color: String = "#FFFFFF",   // NEW
    noteId: Long? = null
): Long

// New folder methods
fun getAllFolders(): Flow<List<String>>
fun getNotesByFolder(folder: String): Flow<List<Note>>
```

### EncryptionUtil.kt
```kotlin
// Added password hashing for verification
fun hashPassword(password: String): String {
    val factory = SecretKeyFactory.getInstance(KEY_DERIVATION_ALGORITHM)
    val spec = PBEKeySpec(
        password.toCharArray(),
        SALT.toByteArray(),
        ITERATION_COUNT,
        256
    )
    val hash = factory.generateSecret(spec).encoded
    return Base64.encodeToString(hash, Base64.DEFAULT)
}
```

## UI Implementation Guide

### Long Press Menu Implementation

Add to `NotesListScreen.kt`:

```kotlin
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NoteCard(
    note: Note,
    onClick: () -> Unit,
    onLongClick: () -> Unit, // NEW
    // ... other params
) {
    var showMenu by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    showMenu = true
                    onLongClick()
                }
            )
    ) {
        // Card content...
    }
    
    // Context Menu
    DropdownMenu(
        expanded = showMenu,
        onDismissRequest = { showMenu = false }
    ) {
        DropdownMenuItem(
            text = { Text("Edit") },
            onClick = { /* navigate to editor */ },
            leadingIcon = { Icon(Icons.Default.Edit, null) }
        )
        DropdownMenuItem(
            text = { Text("Change Color") },
            onClick = { /* show color picker */ },
            leadingIcon = { Icon(Icons.Default.Palette, null) }
        )
        DropdownMenuItem(
            text = { Text("Move to Folder") },
            onClick = { /* show folder picker */ },
            leadingIcon = { Icon(Icons.Default.Folder, null) }
        )
        DropdownMenuItem(
            text = { Text("Delete") },
            onClick = { onDelete() },
            leadingIcon = { Icon(Icons.Default.Delete, null) }
        )
    }
}
```

### Color Picker Dialog

```kotlin
@Composable
fun ColorPickerDialog(
    currentColor: String,
    onColorSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = listOf(
        "#FFFFFF" to "White",
        "#FFEBEE" to "Red",
        "#E8F5E9" to "Green",
        "#E3F2FD" to "Blue",
        "#FFF3E0" to "Orange",
        "#F3E5F5" to "Purple",
        "#FFF9C4" to "Yellow",
        "#E0F2F1" to "Teal"
    )
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose Note Color") },
        text = {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(colors) { (hex, name) ->
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Color(android.graphics.Color.parseColor(hex)))
                            .border(
                                width = if (hex == currentColor) 3.dp else 1.dp,
                                color = if (hex == currentColor) 
                                    MaterialTheme.colorScheme.primary 
                                else 
                                    Color.Gray,
                                shape = CircleShape
                            )
                            .clickable {
                                onColorSelected(hex)
                                onDismiss()
                            }
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
```

### Theme Switcher in Settings

```kotlin
@Composable
fun ThemeSettingsSection(
    currentTheme: String,
    onThemeChanged: (String) -> Unit
) {
    Column {
        Text(
            "Theme",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(16.dp)
        )
        
        RadioButtonOption(
            text = "Light",
            selected = currentTheme == PreferencesManager.THEME_LIGHT,
            onClick = { onThemeChanged(PreferencesManager.THEME_LIGHT) }
        )
        RadioButtonOption(
            text = "Dark",
            selected = currentTheme == PreferencesManager.THEME_DARK,
            onClick = { onThemeChanged(PreferencesManager.THEME_DARK) }
        )
        RadioButtonOption(
            text = "System Default",
            selected = currentTheme == PreferencesManager.THEME_SYSTEM,
            onClick = { onThemeChanged(PreferencesManager.THEME_SYSTEM) }
        )
    }
}
```

### Note Card with Color Background

```kotlin
Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(
        containerColor = Color(android.graphics.Color.parseColor(note.color))
    )
) {
    // Note content...
}
```

## Testing Checklist

- [ ] Password setup saves hash correctly
- [ ] Login screen shows on app reopen
- [ ] Login verifies password correctly
- [ ] Wrong password shows error
- [ ] Long press on note shows menu
- [ ] Color picker changes note color
- [ ] Folder picker moves note to folder
- [ ] Theme switching works immediately
- [ ] Note viewer shows all content
- [ ] Edit from viewer works
- [ ] Delete from viewer works

## Migration Notes

### For Existing Users
When updating from v1 to v2:
1. All existing notes will have default values:
   - `folder`: "" (empty)
   - `color`: "#FFFFFF" (white)
2. Users will need to re-enter password on first launch after update
3. `.fallbackToDestructiveMigration()` will recreate database (DATA LOSS!)

### For Production
Replace in `NotesDatabase.kt`:
```kotlin
// Remove this:
.fallbackToDestructiveMigration()

// Add proper migration:
.addMigrations(MIGRATION_1_2)

// Define migration:
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(database: SupportSQLiteDatabase) {
        database.execSQL(
            "ALTER TABLE notes ADD COLUMN folder TEXT NOT NULL DEFAULT ''"
        )
        database.execSQL(
            "ALTER TABLE notes ADD COLUMN color TEXT NOT NULL DEFAULT '#FFFFFF'"
        )
    }
}
```

## Usage Examples

### 1. Changing Note Color
```kotlin
viewModel.saveNote(
    title = note.title,
    content = note.content,
    tags = note.tags,
    isPinned = note.isPinned,
    folder = note.folder,
    color = "#FFEBEE", // New color!
    noteId = note.id
)
```

### 2. Moving Note to Folder
```kotlin
viewModel.saveNote(
    title = note.title,
    content = note.content,
    tags = note.tags,
    isPinned = note.isPinned,
    folder = "Work", // New folder!
    color = note.color,
    noteId = note.id
)
```

### 3. Filtering by Folder
```kotlin
val workNotes = repository.getNotesByFolder("Work")
    .collectAsState(initial = emptyList())
```

## Performance Considerations

1. **Color Parsing**: Cache parsed colors to avoid repeated `Color.parseColor()` calls
2. **Folder Queries**: Index the `folder` column for faster filtering
3. **Theme Switching**: Use `remember` to cache theme state

## Security Notes

- Password hash uses PBKDF2 with 65,536 iterations
- Hash is stored in SharedPreferences (consider Android Keystore for production)
- Password never stored in plain text
- Each note still has unique IV for encryption

## Future Enhancements

1. **Biometric Authentication**: Add fingerprint/face unlock
2. **Folder Management UI**: Create/rename/delete folders
3. **Color Themes**: Predefined color palettes
4. **Auto-lock**: Lock app after inactivity
5. **Export by Folder**: Backup specific folders
6. **Nested Folders**: Support folder hierarchies

## Support

For issues or questions:
- Check the implementation guide
- Review example code snippets
- Test on emulator first
- Use Android Studio's logcat for debugging

---

**Implementation Status**: ✅ Core features complete, ready for testing
